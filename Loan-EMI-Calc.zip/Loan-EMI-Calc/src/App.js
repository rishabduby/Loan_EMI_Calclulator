import React from 'react';
import Calculator from './components/calculator/Calculator';
// import CalculatorHookForm from './components/calculator/CalculatorHookForm';
import './App.css';

function App() {
  return (
    <div>
      <Calculator />
      {/* <CalculatorHookForm /> */}
    </div>
  );
}

export default App;
