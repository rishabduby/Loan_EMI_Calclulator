import React from 'react'

function fixedFloat(nbr, toFixed = 2) {
    return parseFloat(nbr.toFixed(toFixed));
}

function calculateRepaymentAmount(a, n, i) {
    return (i * a) / (1 - (1 + i) ** -n);
}

export const Table = (props) => {

    const repaymentAmount = fixedFloat(
        calculateRepaymentAmount(
            props.userValues.amount,
            props.userValues.years,
            props.userValues.interest / 100 / 12
        )
    );

    let balance = props.userValues.amount;

    return (
        <>
            <div>
                <table class="table" border="1">
                    {props?.arr.length > 0 &&
                        <thead>
                            <tr>
                                <th scope="col">Installment No</th>
                                <th scope="col">EMI Amount</th>
                                <th scope="col">Principal</th>
                                <th scope="col">Interest</th>
                                <th scope="col">Balance Amount</th>
                            </tr>
                        </thead>
                    }
                    <tbody>
                        {props?.arr.map((number, i) => {
                            const interest = fixedFloat((balance * props.userValues.interest) / 100 / 12);
                            const principal = fixedFloat(repaymentAmount - interest);

                            balance = fixedFloat(balance - principal);
                            console.log(interest, principal, balance)
                            return <tr key={i}>
                                <th scope="row">{i + 1}</th>
                                <td>{Math.round(repaymentAmount)}</td>
                                <td>{Math.round(principal)}</td>
                                <td>{Math.round(interest)}</td>
                                <td>{Math.round(balance)}</td>
                            </tr>

                        })}

                    </tbody>
                </table>
            </div>

        </>
    )
}


